package com.devshiv.tweetsyapp.model

data class TweetListItem(
    var category: String,
    var text:String
)
